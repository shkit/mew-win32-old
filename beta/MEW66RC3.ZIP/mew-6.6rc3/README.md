# Messaging in the Emacs World

- Home page: [http://www.mew.org/](http://www.mew.org/)
- Installation: the github version is available via [MELPA](http://melpa.milkbox.net/)
